﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace RecipeApp1
{
        public partial class MainWindow : Window
        {
            private List<Recipe> allRecipes = new List<Recipe>();

            public MainWindow()
            {
                InitializeComponent();
            }

            // Add Recipe button click event
            private void AddRecipe_Click(object sender, RoutedEventArgs e)
            {
                string recipeName = AddRecipeName.Text;
                int numIngredients = Convert.ToInt32(AddNumIngredients.Text);
                int numSteps = Convert.ToInt32(AddNumSteps.Text);

                List<Ingredient> ingredients = new List<Ingredient>();
                for (int i = 0; i < numIngredients; i++)
                {
                    TextBox AddIngredientName = FindTextBox(icIngredients, "AddIngredientName", i);
                    TextBox AddIngredientQuantity = FindTextBox(icIngredients, "AddIngredientQuantity", i);
                    TextBox AddIngredientUnit = FindTextBox(icIngredients, "AddIngredientUnit", i);
                    TextBox AddIngredientCalories = FindTextBox(icIngredients, "AddIngredientCalories", i);
                    TextBox AddIngredientFoodGroup = FindTextBox(icIngredients, "AddIngredientFoodGroup", i);

                    ingredients.Add(new Ingredient
                    {
                        Name = AddIngredientName.Text,
                        Quantity = Convert.ToDouble(AddIngredientQuantity.Text),
                        Unit = AddIngredientUnit.Text,
                        Calories = Convert.ToInt32(AddIngredientCalories.Text),
                        FoodGroup = AddIngredientFoodGroup.Text
                    });
                }

                List<Step> steps = new List<Step>();
                for (int i = 0; i < numSteps; i++)
                {
                    TextBox AddStepDescription = FindTextBox(icSteps, "AddStepDescription", i);
                    steps.Add(new Step { Description = AddStepDescription.Text });
                }

                Recipe recipe = new Recipe
                {
                    Name = recipeName,
                    Ingredients = ingredients,
                    Steps = steps
                };

                allRecipes.Add(recipe);
                allRecipes = allRecipes.OrderBy(r => r.Name).ToList();
                IRecipes.ItemsSource = allRecipes;
                ClearInputs();
            }

            // Scale Recipe button click event
            private void ScaleRecipe_Click(object sender, RoutedEventArgs e)
            {
                Recipe selectedRecipe = (Recipe)IRecipes.SelectedItem;
                if (selectedRecipe != null)
                {
                    double scaleFactor = GetScaleFactor();
                    selectedRecipe.ScaleIngredients(scaleFactor);
                    DisplayRecipe(selectedRecipe);
                }
                else
                {
                    MessageBox.Show("Please select a recipe to scale.", "Recipe App", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }

            // Reset Quantities button click event
            private void ResetQuantities_Click(object sender, RoutedEventArgs e)
            {
                Recipe selectedRecipe = (Recipe)IRecipes.SelectedItem;
                if (selectedRecipe != null)
                {
                    selectedRecipe.ResetQuantities();
                    DisplayRecipe(selectedRecipe);
                }
                else
                {
                    MessageBox.Show("Please select a recipe to reset quantities.", "Recipe App", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }

            // Clear All button click event
            private void Clear_Click(object sender, RoutedEventArgs e)
            {
                ClearInputs();
            }

            // Recipe selection changed event
            private void RecipeSelectionChanged(object sender, SelectionChangedEventArgs e)
            {
                Recipe selectedRecipe = (Recipe)IRecipes.SelectedItem;
                if (selectedRecipe != null)
                {
                    DisplayRecipe(selectedRecipe);
                }
            }

            // Find a TextBox within an ItemsControl
           private TextBox FindTextBox(ItemsControl itemsControl, string textBoxName, int index)
            {
                var item = itemsControl.ItemContainerGenerator.ContainerFromIndex(index) as ContentPresenter;
                return FindTextBoxByName(item, textBoxName);
            }

            // Find a TextBox within a visual tree by name
            private TextBox FindTextBoxByName(DependencyObject parent, string name)
            {
                int childCount = VisualTreeHelper.GetChildrenCount(parent);
                for (int i = 1; i < childCount; i++)
                {
                    var child = VisualTreeHelper.GetChild(parent, i);
                    if (child is TextBox textBox && textBox.Name == name)
                    {
                        return textBox;
                    }
                    else
                    {
                        TextBox result = FindTextBoxByName(child, name);
                        if (result != null)
                            return result;
                    }
                }
                return null;
            }

            // Get the scale factor from the user
            private double GetScaleFactor()
            {
                double scaleFactor = 1.0;
            Scale scaleFactorWindow = new Scale();
                if (scaleFactorWindow.ShowDialog() == true)
                {
                    scaleFactor = scaleFactorWindow.ScaleFactor;
                }
                return scaleFactor;
            }

            // Display the recipe details
            private void DisplayRecipe(Recipe recipe)
            {
                AddRecipeName.Text = recipe.Name;
                AddNumIngredients.Text = recipe.Ingredients.Count.ToString();
                AddNumSteps.Text = recipe.Steps.Count.ToString();

                icIngredients.ItemsSource = recipe.Ingredients;
                icSteps.ItemsSource = recipe.Steps;

                int totalCalories = recipe.CalculateTotalCalories();
                AddTotalCalories.Text = totalCalories.ToString();

                if (totalCalories > 300)
                {
                    MessageBox.Show("This recipe exceeds 300 calories.", "Recipe App", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
            }

            // Clear all input fields
            private void ClearInputs()
            {
                AddRecipeName.Text = string.Empty;
                AddNumIngredients.Text = string.Empty;
                AddNumSteps.Text = string.Empty;
                icIngredients.ItemsSource = null;
                icSteps.ItemsSource = null;
                AddTotalCalories.Text = "0";
                IRecipes.SelectedIndex = -1;
            }
        }
    }

