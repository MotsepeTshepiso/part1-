﻿using System.Collections.Generic;
using System.Linq;

namespace RecipeApp1
{
    public class Ingredient
    {
        public string Name { get; set; }
        public double Quantity { get; set; }
        public string Unit { get; set; }
        public int Calories { get; set; }
        public string FoodGroup { get; set; }

        // Reset the ingredient quantity to its original value
        public void ResetQuantity()
        {
            // Original quantity is stored in a separate property or database
            Quantity = GetOriginalQuantity();
        }

        // Get the original quantity of the ingredient
        private double GetOriginalQuantity()
        {
            // Retrieve the original quantity from a database or other source
            // Return the original quantity
            return 1.0;
        }
    }
        public class Step
    {
        public string Description { get; set; }
    }
    public class Recipe
    {
        public string Name { get; set; }
        public List<Ingredient> Ingredients { get; set; }
        public List<Step> Steps { get; set; }

        // Scale all ingredient quantities by a given factor
        public void ScaleIngredients(double scaleFactor)
        {
            foreach (Ingredient ingredient in Ingredients)
            {
                ingredient.Quantity *= scaleFactor;
            }
        }

        // Reset all ingredient quantities to their original values
        public void ResetQuantities()
        {
            foreach (Ingredient ingredient in Ingredients)
            {
                ingredient.ResetQuantity();
            }
        }

        // Calculate the total calories of all ingredients in the recipe
        public int CalculateTotalCalories()
        {
            return Ingredients.Sum(i => i.Calories);
        }
    }
}
